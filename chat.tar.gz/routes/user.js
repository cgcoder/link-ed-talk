url = require('url');
/*
 * GET users listing.
 */

exports.list = function(req, res){
  res.send("respond with a resource");
};


/*
 * GET login page.
 */

exports.login = function(req, res){

  query = url.parse(req.url).query;

  if(query && query.page)
  {
    res.render('login', {error: true, err_msg: '',title: 'test' });
  }
  else
  {
    res.render('login', {error: false, title: 'test'});
  }
};

exports.do_login = function(req, res) {
  query = url.parse(req.url).query;

  if (req.body.username)
  {
    console.log('login request for : ' + req.body.username);
    uname = req.body.username;

    if (uname == 'apple' || uname == 'boy' || uname == 'cat')
    {
      console.log('valid user found...'); 
      req.session.userId = uname;
      res.redirect('/secure/user/home');
    }
    else
    {
      res.redirect('/login');
      console.log('invalid users..');
    }
  }
};

exports.home = function(req, res) {
  uname = req.session.userId;
  //console.log(uname + ' rendering');
  res.render('home', {error: false, user: uname, title: uname + '\'s Home'});
}

exports.logout = function(req, res) {
  req.session.uname = null;
  req.session = null;

  res.redirect('/login');
}
