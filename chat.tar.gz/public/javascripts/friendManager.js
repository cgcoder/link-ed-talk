function FriendManager() {
  this.initSocket = function(_socket) {
    this.socket = _socket;
    me = this;
    
    this.socket.on('connection-ok', function(data) { me.handleConnectionOk(data); });
    this.socket.on('refresh-friend-list-reply', function(data) { me.handleRefreshFriendList(data); });
    this.socket.on('friend-online', function(data) { me.handleFriendOnline(data); });
    this.socket.on('friend-offline', function(data) { me.handleFriendOffline(data); });
    this.socket.on('disconnect', function(data) { me.handleDisconnect(data); });
  };
  
  this.handleConnectionOk = function(_data) {
    this.refreshFriendList(_data);
  };
  
  this.refreshFriendList = function(_data) {
    this.socket.emit('refresh-friend-list');
  };
  
  this.handleRefreshFriendList = function(_friendList) {
    for(var i = 0; i < _friendList.length; i++) {
      alert(_friendList[i].encyrptedUserId + ' online ' + _friendList[i].online);
    }
  };
  
  this.handleFriendOnline = function(_friendOnline) {
  };
  
  this.handleFriendOffline = function(_friendOffline) {
  };
  
  this.sendMessage = function(_message) {
  };
  
  this.handleMessageReceive = function(_message) {
  
  };
  
  this.handleDisconnect = function(_message) {
    // TODO: any other clean up here?
    this.socket = null;
  }
  
  this.disconnect = function() {
    //TODO: any other clean up here?
    this.socket = null;
  };
};